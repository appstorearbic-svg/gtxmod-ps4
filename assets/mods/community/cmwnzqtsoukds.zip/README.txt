RACE DUEL 1v1
=============

Files
- index.html: the complete mobile-friendly game.

How to test
1. Upload index.html to a static HTTPS host.
2. Open the same HTTPS URL on both phones.
3. Player 1 taps CREATE ROOM and shares the 6-character code.
4. Player 2 taps JOIN ROOM, enters the code, and joins.
5. Both phones display the same split-screen race: Player 1 at the top, Player 2 at the bottom.

Controls
- ◀ / ▶ steer
- ▲ accelerate
- ▼ brake
- ⚡ nitro
Keyboard: arrows/WASD; Space = nitro.

Important
- This is a playable prototype, not a production-grade multiplayer service.
- It uses PeerJS public signaling and browser WebRTC data channels. Network/firewall/NAT conditions can prevent some connections.
- The 60-minute room expiry is enforced by the host browser while it remains connected.
- For a reliable public launch, use a persistent signaling service and server-side room expiry/race validation.
- The game requires internet access to load PeerJS from its CDN and establish the peer connection.
